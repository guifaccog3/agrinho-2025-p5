// Definindo variáveis globais
let jardineiro
let plantas = [];
let temperatura = 10;
let totalArvores = 0;


function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2,height - 50);
}


function draw() {
 
  // Usando map() para ajustar a cor de fundo de forma mais controlada 
  let corfundo = lerpColor(color(217, 112, 26), color(219, 239, 208),
                           map(totalArvores, 0, 100, 0, 1)); 
  background(corfundo);

  mostrarinformacoes();
  
  temperatura += 0.1;
  
  jardineiro.atualizar();
  jardineiro.mostrar(); 
  
  // Verifica se o jogo acabou 
  verificarFimDeJogo();
  
  // Usando map() para aplicar o comportamento de árvores plantadas
  plantas.map((arvore) => arvore.mostrar());
}

// Função para mostrar as informações na tela 
function mostrarInforcoes() {
  textSize(16);
  fill(0); 
  text("Temperatura: " + temperatura.toFixed(2), 10, 30);
  text("Árvores plantadas: " + totalArvores, 10, 50);
  text("Para movimentar o personagem use as setas do teclado.", 10, 80);
}
// Função para verificar se o jogo acabou 
function verificarFimDeJogo() {
  if (totalArovores > temperatura) {
    